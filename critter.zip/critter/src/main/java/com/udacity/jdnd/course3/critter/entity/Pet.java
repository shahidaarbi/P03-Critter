package com.udacity.jdnd.course3.critter.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Nationalized;
import com.udacity.jdnd.course3.critter.pet.PetType;

/**
 * Represents the form that pet request and response data takes. Does not map to
 * the database directly.
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)

public class Pet {
	public Pet() {
		super();
	}

	@Id
	@GeneratedValue
	private long id;

	@Enumerated(EnumType.STRING)
	//@Column(name="pet_type")
	private PetType type;

	@Nationalized
	private String name;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "customer_Id")
	private Customer customer;

	

	private LocalDate birthDate;
	@Column(length = 500)

	private String notes;

	public void Pet() {
		
	}
	public Pet(PetType type, String name) {
		this.type = type;
		this.name = name;
	}

	public PetType getType() {
		return type;
	}

	public void setType(PetType type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/*
	 * public long getOwnerId() { return ownerId; }
	 * 
	 * public void setOwnerId(long ownerId) { this.ownerId = ownerId; }
	 */

	public LocalDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
}
