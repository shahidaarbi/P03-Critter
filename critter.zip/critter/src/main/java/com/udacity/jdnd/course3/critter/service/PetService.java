package com.udacity.jdnd.course3.critter.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.udacity.jdnd.course3.critter.entity.Pet;
import com.udacity.jdnd.course3.critter.pet.PetDTO;
import com.udacity.jdnd.course3.critter.repository.PetRepository;

@Service
public class PetService {

	@Autowired
	PetRepository petReposotory;

	public PetDTO save(PetDTO petDto) {

		Pet pet = dtoToObj(petDto);
		PetDTO petDtoSaved = objToDTO(petReposotory.save(pet));
		return petDtoSaved;

	}

	public Pet dtoToObj(PetDTO petDTO) {
		Pet pet = new Pet();
		if (petDTO.getName() != null && !petDTO.getName().isEmpty())
			pet.setName(petDTO.getName());

		/*
		 * if (customerDTO.getPetIds() != null && !customerDTO.getPetIds().isEmpty()) {
		 * 
		 * List<PetDTO> petsDTO = new ArrayList<>(customer.getPets());
		 * customer.setPets(new ArrayList<>()); for(PetDTO petDTO: petsDTO)
		 * customer.getPets().add(petDTOHelper.dtoToObj(petDTO)); }
		 */
		return pet;
	}

	public PetDTO objToDTO(Pet pet) {
		PetDTO petdto = new PetDTO();
		if (pet.getId() != 0)
			petdto.setId(pet.getId());
		if (pet.getName() != null && !pet.getName().isEmpty())
			petdto.setName(pet.getName());

		return petdto;
	}

}
