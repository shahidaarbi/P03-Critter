package com.udacity.jdnd.course3.critter.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.udacity.jdnd.course3.critter.entity.Customer;
import com.udacity.jdnd.course3.critter.pet.PetDTO;
import com.udacity.jdnd.course3.critter.repository.CustomerRepository;
import com.udacity.jdnd.course3.critter.user.CustomerDTO;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository customerRepository;

	public CustomerDTO save(CustomerDTO customerDto) {

		Customer customer = dtoToObj(customerDto);
		if(!customer.getPets().isEmpty())
		{
			customer.getPets().forEach(pet->pet.setCustomer(customer));
		}
		customerRepository.save(customer);
		CustomerDTO cus = objToDTO(customerRepository.save(customer));
		return cus;
		
	

	}

	public Customer dtoToObj(CustomerDTO customerDTO) {
		Customer customer = new Customer();
		if (customerDTO.getName() != null && !customerDTO.getName().isEmpty())
			customer.setName(customerDTO.getName());
		if (customerDTO.getNotes() != null && !customerDTO.getNotes().isEmpty())
			customer.setNotes(customerDTO.getNotes());
		if (customerDTO.getPhoneNumber() != null && !customerDTO.getPhoneNumber().isEmpty())
			customer.setPhoneNumber(customerDTO.getPhoneNumber());
	
		 
		return customer;
	}

	public CustomerDTO objToDTO(Customer customer) {
		CustomerDTO customerdto = new CustomerDTO();
		if (customer.getId() != 0)
			customerdto.setId(customer.getId());
		if (customer.getName() != null && !customer.getName().isEmpty())
			customerdto.setName(customer.getName());
		if (customer.getNotes() != null && !customer.getNotes().isEmpty())
			customerdto.setNotes(customer.getNotes());
		if (customer.getPhoneNumber() != null && !customer.getPhoneNumber().isEmpty())
			customerdto.setPhoneNumber(customer.getPhoneNumber());

		return customerdto;
	}

}
